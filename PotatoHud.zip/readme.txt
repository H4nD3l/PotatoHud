this hud will give you the 2011-2016





DISCLAMIER: this hud is under construction meaning it may have bugs


hud installation
first go to c:/program files 86x/steam/steamapps/team fortress 2/tf/custom and then paste the hud there


if you got a bug
contact me at


https://www.steamcommunity.com/profiles/76561199161488419
